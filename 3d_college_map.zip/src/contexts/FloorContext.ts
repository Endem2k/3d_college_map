import { createContext } from "react";

export const FloorContext = createContext(2)